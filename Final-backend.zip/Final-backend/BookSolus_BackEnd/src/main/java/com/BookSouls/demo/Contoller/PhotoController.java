package com.BookSouls.demo.Contoller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class PhotoController {

}
