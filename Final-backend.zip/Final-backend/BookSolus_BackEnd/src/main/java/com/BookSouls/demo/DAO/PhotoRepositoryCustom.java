package com.BookSouls.demo.DAO;

public interface PhotoRepositoryCustom {
	public int getMaxPhotoId();
}
