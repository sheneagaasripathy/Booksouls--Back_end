package com.BookSouls.demo.DAO;

public interface PendingDetailsRepositoryCutom {
	public int getMaxPendingDetailID();
}
