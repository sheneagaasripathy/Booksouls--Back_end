package com.BookSouls.demo.DAO;


public interface BookRepositoryCustom {
	public long getMaxBookID();
}
